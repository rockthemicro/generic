#!/bin/sh

echo Installing dotfiles to $HOME

# backup files will be formated as <old_name>-$backup_str-<timestamp>
backup_str=dotfiles-backup

create_backup () {
	# $1 - working directory
	# $2 - file name
	now=`date +%s`
	bck=$2-$backup_str-$now
	echo Backing up old $2 to $1/$bck
	mv $1/$2 $1/$bck
}

echo Installing vim configuration
if [ -a $HOME/.vimrc ]; then
	create_backup $HOME .vimrc
fi
cp ./vimrc $HOME/.vimrc
if [ -d $HOME/.vim ]; then
	create_backup $HOME .vim
fi
cp -R ./vim $HOME/.vim

echo Installing tmux configuration
if [ -a $HOME/.tmux.conf ]; then
	create_backup $HOME .tmux.conf
fi
cp ./tmux.conf $HOME/.tmux.conf


echo Installing custom bash scripts
cp ./git-completion.bash $HOME/.git-completion.bash
cp ./bashrc-custom $HOME/.bashrc-custom
if grep "source.\+\.bashrc-custom" $HOME/.bashrc > /dev/null; then
	echo .bashrc-custom already sourced in .bashrc
else
	echo sourcing .bashrc-custom in .bashrc
	{
		echo
		echo \# custom bashrc added by the dotfiles installer
		echo source $HOME/.bashrc-custom
	} >> $HOME/.bashrc
fi

echo
echo Done. Don't forget to 'source $HOME/.bashrc.
